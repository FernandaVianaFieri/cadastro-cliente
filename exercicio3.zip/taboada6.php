<?php

	for($n=1; $n<=10; $n++)
	{
		echo $n . " x 6 = " . ($n*6) . "<br>";
	}
?>

