<?php


for ($n=2021; $n>=1989; $n--)
{
	echo "$n <br>";
}